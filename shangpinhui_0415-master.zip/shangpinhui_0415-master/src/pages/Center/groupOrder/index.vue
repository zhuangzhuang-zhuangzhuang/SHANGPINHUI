<template>
  <div>
       我是团购订单内容
  </div>
</template>

<script>
export default {
  name: '',
}
</script>

<style scoped>

</style>
